#include <stdio.h>

double getStdDeviation(double*nums, double avg , int cant_muestras);
double getAverage(double*nums, int cant_muestras);
unsigned long int percentage (unsigned long int totalNumber , unsigned long int percentage);


