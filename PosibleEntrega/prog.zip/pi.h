#include <stdio.h>


void pi(int n_steps , int option);
double generatorPI(int n , int n_steps); //Donde se invoca esta función ??
double generatorPIr(int n , int n_steps);
double generatorPInra(int n , int n_steps);
double generatorPInrc(int n , int n_steps);
double generatorPIr2(int n , int n_steps);
double generatorPIrD(int n , int n_steps);
double pickerPi (int num, int i , int n_steps);

double pruebaGuided(int n ,int percen , int n_steps);
double pruebaDynamic(int n ,int percen , int n_steps);
double pruebaStatic(int n ,int percen , int n_steps);


